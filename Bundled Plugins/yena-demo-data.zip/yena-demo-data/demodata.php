<?php

// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_yena_get_demo_array($dir_url, $dir_path){

    $demo_items = array(
        'home-01' => array(
            'link'          => 'https://yena.la-studioweb.com/home-01/',
            'title'         => 'Beauty 01',
            'data_sample'   => 'data.json',
            'data_product'  => 'product.csv',
            'data_widget'   => 'widget.json',
            'data_slider'   => 'main-01.zip',
            'category'      => array(
                'Demo',
	            'Beauty',
                'Cosmetic'
            )
        ),
        'home-02' => array(
            'link'          => 'https://yena.la-studioweb.com/home-02/',
            'title'         => 'Beauty 02',
            'data_sample'   => 'data.json',
            'data_product'  => 'product.csv',
            'data_widget'   => 'widget.json',
            'data_slider'   => 'main-02.zip',
            'category'      => array(
                'Demo',
	            'Beauty',
                'Cosmetic'
            )
        ),
        'home-03' => array(
            'link'          => 'https://yena.la-studioweb.com/home-03/',
            'title'         => 'Beauty 03',
            'data_sample'   => 'data.json',
            'data_product'  => 'product.csv',
            'data_widget'   => 'widget.json',
            'data_slider'   => 'main-03.zip',
            'category'      => array(
                'Demo',
	            'Beauty',
                'Cosmetic'
            )
        ),
        'home-04' => array(
            'link'          => 'https://yena.la-studioweb.com/home-04/',
            'title'         => 'Beauty 04',
            'data_sample'   => 'data.json',
            'data_product'  => 'product.csv',
            'data_widget'   => 'widget.json',
            'data_slider'   => 'main-04.zip',
            'category'      => array(
                'Demo',
	            'Beauty',
                'Cosmetic'
            )
        ),
        'home-05' => array(
            'link'          => 'https://yena.la-studioweb.com/home-05/',
            'title'         => 'Beauty 05',
            'data_sample'   => 'data.json',
            'data_product'  => 'product.csv',
            'data_widget'   => 'widget.json',
            'data_slider'   => 'main-05.zip',
            'category'      => array(
                'Demo',
	            'Beauty',
                'Cosmetic'
            )
        ),
        'home-06' => array(
            'link'          => 'https://yena.la-studioweb.com/home-06/',
            'title'         => 'Beauty 06',
            'data_sample'   => 'data.json',
            'data_product'  => 'product.csv',
            'data_widget'   => 'widget.json',
            'data_slider'   => 'main-06.zip',
            'category'      => array(
                'Demo',
	            'Beauty',
                'Cosmetic'
            )
        ),
        'home-07' => array(
            'link'          => 'https://yena.la-studioweb.com/home-07/',
            'title'         => 'Beauty 08',
            'data_sample'   => 'data.json',
            'data_product'  => 'product.csv',
            'data_widget'   => 'widget.json',
            'category'      => array(
                'Demo',
	            'Beauty',
                'Cosmetic'
            )
        ),
        'home-08' => array(
            'link'          => 'https://yena.la-studioweb.com/home-08/',
            'title'         => 'Beauty 08',
            'data_sample'   => 'data.json',
            'data_product'  => 'product.csv',
            'data_widget'   => 'widget.json',
            'category'      => array(
                'Demo',
	            'Beauty',
                'Cosmetic'
            )
        )
    );

    $default_image_setting = array(
        'woocommerce_single_image_width' => 1000,
        'woocommerce_thumbnail_image_width' => 1000,
        'woocommerce_thumbnail_cropping' => 'custom',
        'woocommerce_thumbnail_cropping_custom_width' => 10,
        'woocommerce_thumbnail_cropping_custom_height' => 12,
        'thumbnail_size_w' => 520,
        'thumbnail_size_h' => 340,
        'medium_size_w' => 0,
        'medium_size_h' => 0,
        'medium_large_size_w' => 0,
        'medium_large_size_h' => 0,
        'large_size_w' => 0,
        'large_size_h' => 0
    );

    $default_menu = array(
        'main-nav'              => 'Primary Navigation'
    );

    $default_page = array(
        'page_for_posts' 	            => 'Blog',
        'woocommerce_shop_page_id'      => 'Shop',
        'woocommerce_cart_page_id'      => 'Cart',
        'woocommerce_checkout_page_id'  => 'Checkout',
        'woocommerce_myaccount_page_id' => 'My Account'
    );

    $slider = $dir_path . 'Slider/';
    $content = $dir_path . 'Content/';
    $product = $dir_path . 'Product/';
    $widget = $dir_path . 'Widget/';
    $setting = $dir_path . 'Setting/';
    $preview = $dir_url;


    if(class_exists('LAHB_Helper')){
        $header_presets = LAHB_Helper::getHeaderDefaultData();

        $header_01 = json_decode($header_presets['yena-header-01']['data'], true);
        $header_02 = json_decode($header_presets['yena-header-02']['data'], true);
        $header_03 = json_decode($header_presets['yena-header-03']['data'], true);
        $header_04 = json_decode($header_presets['yena-header-04']['data'], true);
        $header_05 = json_decode($header_presets['yena-header-05']['data'], true);
        $header_06 = json_decode($header_presets['yena-header-06']['data'], true);
        $header_vertical_01 = json_decode($header_presets['yena-header-vertical-01']['data'], true);
        $header_vertical_02 = json_decode($header_presets['yena-header-vertical-02']['data'], true);

        $demo_items['home-01']['other_setting'] = $header_01;
        $demo_items['home-02']['other_setting'] = $header_04;
        $demo_items['home-03']['other_setting'] = $header_02;
        $demo_items['home-04']['other_setting'] = $header_05;
        $demo_items['home-05']['other_setting'] = $header_02;
        $demo_items['home-06']['other_setting'] = $header_vertical_02;
        $demo_items['home-07']['other_setting'] = $header_01;
        $demo_items['home-08']['other_setting'] = $header_01;

    }

    $data_return = array();

    foreach ($demo_items as $demo_key => $demo_detail){
	    $value = array();
	    $value['title']             = $demo_detail['title'];
	    $value['category']          = !empty($demo_detail['category']) ? $demo_detail['category'] : array('Demo');
	    $value['demo_preset']       = $demo_key;
	    $value['demo_url']          = $demo_detail['link'];
	    $value['preview']           = !empty($demo_detail['preview']) ? $demo_detail['preview'] : ($preview . $demo_key . '.jpg');
	    $value['option']            = $setting . $demo_key . '.json';
	    $value['content']           = !empty($demo_detail['data_sample']) ? $content . $demo_detail['data_sample'] : $content . 'sample-data.json';
	    $value['product']           = !empty($demo_detail['data_product']) ? $product . $demo_detail['data_product'] : $product . 'sample-product.json';
	    $value['widget']            = !empty($demo_detail['data_widget']) ? $widget . $demo_detail['data_widget'] : $widget . 'widget.json';
	    $value['pages']             = array_merge( $default_page, array( 'page_on_front' => $demo_detail['title'] ));
	    $value['menu-locations']    = array_merge( $default_menu, isset($demo_detail['menu-locations']) ? $demo_detail['menu-locations'] : array());
	    $value['other_setting']     = array_merge( $default_image_setting, isset($demo_detail['other_setting']) ? $demo_detail['other_setting'] : array());
	    if(!empty($demo_detail['data_slider'])){
		    $value['slider'] = $slider . $demo_detail['data_slider'];
	    }
	    $data_return[$demo_key] = $value;
    }

    return $data_return;
}