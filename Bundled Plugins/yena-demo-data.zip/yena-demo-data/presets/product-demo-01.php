<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_yena_preset_product_demo_01()
{
    return [
        [
            'key' => 'woocommerce_product_page_design',
            'value' => '1'
        ],
        [
            'key'       => 'product_gallery_column',
            'value'     => [
                'mobile' => 3,
                'mobile_landscape' => 4,
                'tablet' => 3,
                'laptop' => 4,
                'desktop' => 4
            ]
        ],
    ];
}