<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_yena_preset_blog_left_sidebar()
{
    return [
        [
            'key'       => 'layout_blog',
            'value'     => 'col-2cl'
        ],
	    [
            'key'       => 'main_space_archive_post',
            'value'     => [
	            'laptop' => [
		            'top' => '130',
		            'bottom' => '100'
	            ]
            ]
        ],
	    [
            'key'       => 'blog_item_space',
            'value'     => [
	            'laptop' => [
		            'bottom' => '80'
	            ]
            ]
        ],
        [
            'filter_name'       => 'yena/filter/current_title',
            'filter_func'       => function( $title ) {
                $title = 'Blog Left Sidebar';
                return $title;
            },
            'filter_priority'   => 10,
            'filter_args'       => 1
        ],
        [
            'filter_name'       => 'yena/filter/get_option',
            'filter_func'       => function( $value, $key ) {
                if( $key == 'la_custom_css'){
                    $value .= '.site-content > .la-pagination { text-align: center;}';
                }
                return $value;
            },
            'filter_priority'   => 10,
            'filter_args'       => 2
        ],
    ];
}