<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_yena_preset_shop_masonry()
{
    return [
        [
            'filter_name'       => 'yena/filter/current_title',
            'filter_func'       => function( $title ) {
                $title = 'Shop Masonry';
                return $title;
            },
            'filter_priority'   => 10,
            'filter_args'       => 1
        ],
	    [
		    'key'               => 'layout_archive_product',
		    'value'             => 'col-1c'
	    ],

        [
            'key' => 'shop_catalog_grid_style',
            'value' => '6'
        ],
        [
            'key' => 'woocommerce_pagination_type',
            'value' => 'load_more'
        ],
        [
            'key' => 'product_masonry_image_size',
            'value' => 'full'
        ],
        [
            'key' => 'woocommerce_toggle_grid_list',
            'value' => 'off'
        ],
        [
            'key' => 'active_shop_masonry',
            'value' => 'on'
        ],
        [
            'key' => 'shop_masonry_column_type',
            'value' => 'custom'
        ],
        [
            'key' => 'product_masonry_container_width',
            'value' => 1570
        ],
        [
            'key' => 'product_masonry_item_width',
            'value' => 370
        ],
        [
            'key' => 'product_masonry_item_height',
            'value' => 480
        ],
        [
            'key' => 'woocommerce_shop_masonry_custom_columns',
            'value' => [
                'mobile' => 1,
                'mobile_landscape' => 2,
                'tablet' => 3,
                'laptop' => 3
            ]
        ],
        [
            'key' => 'enable_shop_masonry_custom_setting',
            'value' => 'on'
        ],
        [
            'key' => 'shop_masonry_item_setting',
            'value' => [
                0 => [
                    'size_name' => '1w x 1h',
                    'w'         => 1,
                    'h'         => 1,
                ],
                1 => [
	                'size_name' => '1w x 0.75h',
                    'w'         => 1,
                    'h'         => 0.75,
                ],
                2 => [
                    'size_name' => '1w x 1h',
                    'w'         => 1,
                    'h'         => 1,
                ],
                3 => [
                    'size_name' => '1w x 0.75h',
                    'w'         => 1,
                    'h'         => 0.75,
                ]
            ]
        ],
        [
            'key' => 'shop_item_space',
            'value' => [
                'mobile' => [
                    'left' => '15',
                    'right' => '15',
                    'bottom' => '30'
                ]
            ]
        ],
        [
            'filter_name'       => 'yena/filter/get_option',
            'filter_func'       => function( $value, $key ) {
                if( $key == 'la_custom_css'){
                    $value .= '.la-pagination.active-loadmore {margin-top: 2em;}';
                }
                return $value;
            },
            'filter_priority'   => 10,
            'filter_args'       => 2
        ]
    ];
}