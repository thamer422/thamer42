<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_yena_preset_shop_sidebar_left()
{
    return [
    	[
    		'key'               => 'layout_archive_product',
		    'value'             => 'col-2cl'
	    ],
	    [
		    'key'               => 'woocommerce_shop_page_columns',
		    'value'             => [
			    'desktop' => 3,
			    'laptop' => 3,
			    'tablet' => 2,
			    'mobile_landscape' => 2,
			    'mobile' => 1
		    ]
	    ],
        [
            'filter_name'       => 'yena/filter/current_title',
            'filter_func'       => function( $title ) {
                $title = 'Shop Sidebar';
                return $title;
            },
            'filter_priority'   => 10,
            'filter_args'       => 1
        ]
    ];
}