<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_yena_preset_home_08()
{
    return [
        [
            'key'           => 'header_transparency',
            'value'         => 'yes'
        ],
        [
            'key'               => 'footer_layout',
            'value'             => 67
        ],
        [
            'filter_name' => 'LaStudio_Builder/logo_transparency_url',
            'value'       => get_theme_file_uri('/assets/images/logo-white2.svg')
        ],
    ];
}