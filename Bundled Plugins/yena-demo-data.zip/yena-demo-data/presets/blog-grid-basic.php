<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_yena_preset_blog_grid_basic()
{
    return [
        [
            'key'       => 'layout_blog',
            'value'     => 'col-1c'
        ],
        [
            'key'       => 'blog_design',
            'value'     => 'grid-2'
        ],
        [
            'key'       => 'blog_thumbnail_height_mode',
            'value'     => 'custom'
        ],
        [
            'key'       => 'blog_thumbnail_height_custom',
            'value'     => '78%'
        ],
	    [
            'key'       => 'blog_pagination_type',
            'value'     => 'load_more'
        ],
	    [
            'key'       => 'main_space_archive_post',
            'value'     => [
	            'laptop' => [
		            'top' => '130',
		            'bottom' => '100'
	            ]
            ]
        ],
        [
            'key'       => 'blog_post_column',
            'value'     => [
                'mobile' => 1,
                'mobile_landscape' => 2,
                'tablet' => 2,
                'laptop' => 3,
                'desktop' => 3,
            ]
        ],
	    [
            'key'       => 'blog_item_space',
            'value'     => [
	            'tablet' => [
		            'bottom' => '30'
	            ]
            ]
        ],
        [
            'filter_name'       => 'yena/filter/current_title',
            'filter_func'       => function( $title ) {
                $title = 'Blog Grid Basic';
                return $title;
            },
            'filter_priority'   => 10,
            'filter_args'       => 1
        ],
        [
            'filter_name'       => 'yena/filter/get_option',
            'filter_func'       => function( $value, $key ) {
                if( $key == 'la_custom_css'){
                    $value .= '
#main{
  background-color: #f9f9f9
}
.site-content > .la-pagination{
  margin-top: 4em;
  text-align: center;
}
@media(min-width: 1200px){
.lastudio-posts.blog__entries .loop__item.format-quote .lastudio-posts__inner-content{
  display: none;
}
.lastudio-posts.blog__entries .loop__item.format-quote .post-thumbnail{
  display: flex;
  height: auto;
  flex-grow: 1;
}
.lastudio-posts.blog__entries .loop__item.format-quote .lastudio-posts__inner-box{
  display: flex;
  flex-flow: column wrap;
  justify-content: stretch;
}
.lastudio-posts.blog__entries .loop__item.format-quote .post-thumbnail .blog_item--thumbnail{
  padding: 0;
  position: static;
}
.lastudio-posts.blog__entries .loop__item.format-quote .quote-wrapper{
  background-color: rgba(33, 30, 28, 0.4) !important;
}
.lastudio-posts.blog__entries .loop__item.format-quote .quote-wrapper .format-content{
  padding: 30px 30px 40px;
  border-top: 1px solid;
  overflow: hidden;
  border-bottom: 0;
  text-align: center;
}
.lastudio-posts.blog__entries .loop__item.format-quote .quote-author{
  position: absolute;
  left: 50%;
  bottom: 0;
  transform: translateX(-50%);
  height: 20px;
}
.lastudio-posts.blog__entries .loop__item.format-quote .quote-author:after{
  content: "";
  width: 300%;
  border-top: 1px solid #fff;
  position: absolute;
  right: 100%;
  margin-right: 10px;
  top: 10px;
}
.lastudio-posts.blog__entries .loop__item.format-quote .quote-author:before{
  content: "";
  width: 300%;
  border-top: 1px solid #fff;
  position: absolute;
  left: 100%;
  margin-left: 10px;
  top: 10px;
}
.lastudio-posts.blog__entries .loop__item.format-quote .quote-wrapper .format-content:before{
  content: "";
  border-left: 1px solid;
  position: absolute;
  left: 0;
  top: 0;
  height: calc(100% - 10px);
}
.lastudio-posts.blog__entries .loop__item.format-quote .quote-wrapper .format-content:after{
  content: "";
  border-left: 1px solid;
  position: absolute;
  right: 0;
  top: 0;
  height: calc(100% - 10px);
}
}
';
                }
                return $value;
            },
            'filter_priority'   => 10,
            'filter_args'       => 2
        ],
    ];
}