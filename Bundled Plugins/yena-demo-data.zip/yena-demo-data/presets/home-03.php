<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_yena_preset_home_03()
{
    return [
        [
            'key'               => 'header_layout',
            'value'             => 'yena-header-02'
        ],
        [
            'key'               => 'footer_layout',
            'value'             => 64
        ],
    ];
}