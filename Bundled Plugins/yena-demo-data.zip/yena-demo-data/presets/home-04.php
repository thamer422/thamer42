<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_yena_preset_home_04()
{
    return [
        [
            'key'               => 'header_layout',
            'value'             => 'yena-header-05'
        ],
        [
            'key'               => 'header_transparency',
            'value'             => 'yes'
        ],
        [
            'filter_name'       => 'yena/filter/get_option',
            'filter_func'       => function( $value, $key ) {
                if( $key == 'la_custom_css'){
                    $value .= '
@media(min-width: 1400px){
    #lastudio-header-builder {
        top: 100px;
    }
}

#lastudio-header-builder:not(.is-sticky) .lahb-desktop-view .lahb-area > .container {
    max-width: 83%;
}
                    ';
                }
                return $value;
            },
            'filter_priority'   => 10,
            'filter_args'       => 2
        ],
    ];
}