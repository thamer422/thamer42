<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_yena_preset_home_05()
{
    return [
        [
            'key'               => 'header_layout',
            'value'             => 'yena-header-02'
        ],
        [
            'filter_name'       => 'yena/filter/get_option',
            'filter_func'       => function( $value, $key ) {
                if( $key == 'la_custom_css'){
                    $value .= '
#lastudio-header-builder {
    box-shadow: 0 0 3px rgba(0,0,0,.2);
}
                    ';
                }
                return $value;
            },
            'filter_priority'   => 10,
            'filter_args'       => 2
        ],
    ];
}