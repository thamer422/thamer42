<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
    exit( 'Direct script access denied.' );
}

function la_yena_preset_shop_fullwidth()
{
    return [
    	[
    		'key'               => 'layout_archive_product',
		    'value'             => 'col-1c'
	    ],
	    [
		    'key'               => 'woocommerce_shop_page_columns',
		    'value'             => [
			    'desktop' => 4,
			    'laptop' => 4,
			    'tablet' => 3,
			    'mobile_landscape' => 2,
			    'mobile' => 2
		    ]
	    ],
        [
            'filter_name'       => 'yena/filter/current_title',
            'filter_func'       => function( $title ) {
                $title = 'Shop Fullwidth';
                return $title;
            },
            'filter_priority'   => 10,
            'filter_args'       => 1
        ]
    ];
}