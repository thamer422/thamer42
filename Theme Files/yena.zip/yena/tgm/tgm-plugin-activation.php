<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

add_action( 'tgmpa_register', 'yena_register_required_plugins' );

if(!function_exists('lasf_get_plugin_source')){
    function lasf_get_plugin_source( $new, $initial, $plugin_name, $type = 'source'){
        if(isset($new[$plugin_name], $new[$plugin_name][$type]) && version_compare($initial[$plugin_name]['version'], $new[$plugin_name]['version']) < 0 ){
            return $new[$plugin_name][$type];
        }
        else{
            return $initial[$plugin_name][$type];
        }
    }
}

if(!function_exists('yena_register_required_plugins')){

	function yena_register_required_plugins() {

        $initial_required = array(
            'lastudio' => array(
                'source'    => 'https://la-studioweb.com/file-resouces/shared/plugins/lastudio_v2.0.16.zip',
                'version'   => '2.0.16'
            ),
            'lastudio-header-builders' => array(
                'source'    => 'https://la-studioweb.com/file-resouces/shared/plugins/lastudio-header-builders_v1.1.8.zip',
                'version'   => '1.1.8'
            ),
            'revslider' => array(
                'source'    => 'https://la-studioweb.com/file-resouces/shared/plugins/revslider_v6.3.6.zip',
                'version'   => '6.3.6'
            ),
            'yena-demo-data' => array(
                'source'    => 'https://la-studioweb.com/file-resouces/yena/plugins/yena-demo-data/1.0.1/yena-demo-data.zip',
                'version'   => '1.0.1'
            )
        );

        $from_option = get_option('yena_required_plugins_list', $initial_required);

		$plugins = array();

		$plugins[] = array(
			'name'					=> esc_html_x('LA-Studio Core', 'admin-view', 'yena'),
			'slug'					=> 'lastudio',
            'source'				=> lasf_get_plugin_source($from_option, $initial_required, 'lastudio'),
            'required'				=> true,
            'version'				=> lasf_get_plugin_source($from_option, $initial_required, 'lastudio', 'version')
		);

		$plugins[] = array(
			'name'					=> esc_html_x('LA-Studio Header Builder', 'admin-view', 'yena'),
			'slug'					=> 'lastudio-header-builders',
            'source'				=> lasf_get_plugin_source($from_option, $initial_required, 'lastudio-header-builders'),
            'required'				=> true,
            'version'				=> lasf_get_plugin_source($from_option, $initial_required, 'lastudio-header-builders', 'version')
		);

        $plugins[] = array(
            'name' 					=> esc_html_x('Elementor', 'admin-view', 'yena'),
            'slug' 					=> 'elementor',
            'required' 				=> true,
            'version'				=> '3.1.0'
        );

		$plugins[] = array(
			'name'     				=> esc_html_x('WooCommerce', 'admin-view', 'yena'),
			'slug'     				=> 'woocommerce',
			'version'				=> '4.9.2',
			'required' 				=> false
		);
        
        $plugins[] = array(
			'name'     				=> esc_html_x('Yena Package Demo Data', 'admin-view', 'yena'),
			'slug'					=> 'yena-demo-data',
            'source'				=> lasf_get_plugin_source($from_option, $initial_required, 'yena-demo-data'),
            'required'				=> false,
            'version'				=> lasf_get_plugin_source($from_option, $initial_required, 'yena-demo-data', 'version')
		);

		$plugins[] = array(
			'name'     				=> esc_html_x('Envato Market', 'admin-view', 'yena'),
			'slug'     				=> 'envato-market',
			'source'   				=> 'https://envato.github.io/wp-envato-market/dist/envato-market.zip',
			'required' 				=> false,
			'version' 				=> '2.0.6'
		);

		$plugins[] = array(
			'name' 					=> esc_html_x('Contact Form 7', 'admin-view', 'yena'),
			'slug' 					=> 'contact-form-7',
			'required' 				=> false
		);

		$plugins[] = array(
			'name'					=> esc_html_x('Slider Revolution', 'admin-view', 'yena'),
			'slug'					=> 'revslider',
            'source'				=> lasf_get_plugin_source($from_option, $initial_required, 'revslider'),
            'required'				=> false,
            'version'				=> lasf_get_plugin_source($from_option, $initial_required, 'revslider', 'version')
		);

		$config = array(
			'id'           				=> 'yena',
			'default_path' 				=> '',
			'menu'         				=> 'tgmpa-install-plugins',
			'has_notices'  				=> true,
			'dismissable'  				=> true,
			'dismiss_msg'  				=> '',
			'is_automatic' 				=> false,
			'message'      				=> ''
		);

		tgmpa( $plugins, $config );

	}

}
